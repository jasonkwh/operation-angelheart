/*
* Energy Bar Toolkit by Mad Pixel Machine
* http://www.madpixelmachine.com
*/

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace EnergyBarToolkit {

public class MadShaders {

    // ===========================================================
    // Constants
    // ===========================================================
    
    public const string UnlitTint = "Energy Bar Toolkit/Unlit/Transparent Tint";
    public const string UnlitTintDepthBased = "Energy Bar Toolkit/Unlit/Transparent Tint Depth Based";
    public const string UnlitTintPre = "Energy Bar Toolkit/Unlit/Transparent Tint Pre";
    public const string UnlitTintPreDepthBased = "Energy Bar Toolkit/Unlit/Transparent Tint Pre Depth Based";
    public const string Font = "Energy Bar Toolkit/Unlit/Font";
    public const string FontDepthBased = "Energy Bar Toolkit/Unlit/Font Depth Based";
    public const string FontWhite = "Energy Bar Toolkit/Unlit/Font White";
    public const string FontWhiteDepthBased = "Energy Bar Toolkit/Unlit/Font White Depth Based";

    // ===========================================================
    // Fields
    // ===========================================================

    // ===========================================================
    // Methods for/from SuperClass/Interfaces
    // ===========================================================

    // ===========================================================
    // Methods
    // ===========================================================

    void Start() {
    }

    void Update() {
    }

    // ===========================================================
    // Static Methods
    // ===========================================================

    // ===========================================================
    // Inner and Anonymous Classes
    // ===========================================================

}

} // namespace